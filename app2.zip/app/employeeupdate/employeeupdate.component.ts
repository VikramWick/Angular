import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employeeupdate',
  templateUrl: './employeeupdate.component.html',
  styleUrls: ['./employeeupdate.component.css']
})
  export class EmployeeupdateComponent implements OnInit {
    employeeId: number=0;
    employee: any = {};

    constructor(
      private employeeService: EmployeeService,
      private route: ActivatedRoute,
      private router: Router
    ) { }

    ngOnInit(): void {
      this.employeeId = this.route.snapshot.params['id'];
      this.employeeService.getEmployeeById(this.employeeId).subscribe(data => {
        this.employee = data;
      });
    }

    updateEmployee() {
      this.employeeService.updateEmployee(this.employeeId, this.employee).subscribe(data => {
        console.log('Employee updated successfully');
        this.router.navigate(['/employees']);
      }, (error: any) => console.log(error));
    }
  }
