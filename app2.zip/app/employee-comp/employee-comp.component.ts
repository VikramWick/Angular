import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/employee';
import { EmployeeServiceService } from 'src/employee-service.service';

@Component({
  selector: 'app-employee-comp',
  templateUrl: './employee-comp.component.html',
  styleUrls: ['./employee-comp.component.css']
})
export class EmployeeCompComponent implements OnInit {
  public employees:Employee[]=[];


  constructor(private employeeService:EmployeeServiceService) { }

  ngOnInit(): void {
    this.employeeService.getEmployees().subscribe((data:Employee[])=>{
      console.log(data);
      this.employees=data;
    });
  }

}
