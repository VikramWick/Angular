import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttonclick',
  templateUrl: './buttonclick.component.html',
  styleUrls: ['./buttonclick.component.css']
})
export class ButtonclickComponent implements OnInit {

  name:string="vikram";
  pname:string="";
  date1:string="";
  date:string=new Date().toDateString();

  constructor() { }

  ngOnInit(): void {
  }

  print(){
    this.pname=this.name;
    this.date1=new Date().toDateString();
  }


}
