import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloworldComponent } from './helloworld/helloworld.component';
import { AddressCardComponent } from './address-card/address-card.component';
import { TwowaybindingComponent } from './twowaybinding/twowaybinding.component';
import { FormsModule } from '@angular/forms';
import { NgstyleComponent } from './ngstyle/ngstyle.component';
import { ToggleComponent } from './toggle/toggle.component';
import { ButtonclickComponent } from './buttonclick/buttonclick.component';
import { AnnotationsComponent } from './annotations/annotations.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { Child2parentComponent } from './child2parent/child2parent.component';
import { SemployeeComponent } from './semployee/semployee.component';
import { EmployeedetailComponent } from './employeedetail/employeedetail.component';
import { PipedemoPipe } from './pipedemo.pipe';
import { PipeDComponent } from './pipe-d/pipe-d.component';
import { HomeComponent } from './home/home.component';
import { TemplateformComponent } from './templateform/templateform.component';

@NgModule({
  declarations: [
    AppComponent,
    HelloworldComponent,
    AddressCardComponent,
    TwowaybindingComponent,
    NgstyleComponent,
    ToggleComponent,
    ButtonclickComponent,
    AnnotationsComponent,
    ParentComponent,
    ChildComponent,
    Child2parentComponent,
    SemployeeComponent,
    EmployeedetailComponent,
    PipedemoPipe,
    PipeDComponent,
    HomeComponent,
    TemplateformComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
