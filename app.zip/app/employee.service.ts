import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employee=[
    {"id":1,"name":"John","age":25},
    {"id":2,"name":"Smith","age":30},
    {"id":3,"name":"Kenny","age":35},
  ]

  constructor() { }

  getEmployees(){
    return this.employee;
  }
}
