import { Component, OnInit } from '@angular/core';
import { User } from '../user';

@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css']
})
export class TemplateformComponent implements OnInit {

  
  user:User = new User();
  constructor() { }

  ngOnInit(): void {
  }

  topics = ['Angular', 'React', 'jQuery'];

  onSubmit(form: any) {
    console.log('Form value:', form.value);
    this.user.ename = form.value.ename;
    this.user.email = form.value.email;
    this.user.street = form.value.street;
    this.user.city = form.value.city;
    this.user.state = form.value.state;
    this.user.phone = form.value.phone;
    this.user.topic = form.value.topic;
    this.user.offers = form.value.offers;
    alert(`Form Submission Details:
      Name: ${this.user.ename}
      Email: ${this.user.email}
      Street: ${this.user.street}
      City: ${this.user.city}
      State: ${this.user.state}
      Phone: ${this.user.phone}
      Topic: ${this.user.topic}
      Accepts Offers: ${this.user.offers ? 'Yes' : 'No'}`);
    
  }
}
