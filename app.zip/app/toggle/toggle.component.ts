import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toggle',
  templateUrl: './toggle.component.html',
  styleUrls: ['./toggle.component.css']
})
export class ToggleComponent implements OnInit {

  title="Toggle Component";
  isDisabled=false;
  value:number|string='';
  age:number=0;
  ageS:number=0;

  constructor() { }

  enable(){
    this.isDisabled=!this.isDisabled;
  }

  ngOnInit(): void {
  }

  submitAge(){
    this.ageS=this.age;
  }

}
