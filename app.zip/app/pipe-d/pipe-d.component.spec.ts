import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PipeDComponent } from './pipe-d.component';

describe('PipeDComponent', () => {
  let component: PipeDComponent;
  let fixture: ComponentFixture<PipeDComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PipeDComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipeDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
