import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe-d',
  templateUrl: './pipe-d.component.html',
  styleUrls: ['./pipe-d.component.css']
})
export class PipeDComponent implements OnInit {

  today: Date=new Date();
  amount:number=1000;
  st:string="Hello";
  constructor() { }

  ngOnInit(): void {
  }

}
