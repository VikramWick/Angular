import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'append'
})
export class PipedemoPipe implements PipeTransform {

  transform(value: string, appendText: string): string {
    return value+appendText;
  }

}
