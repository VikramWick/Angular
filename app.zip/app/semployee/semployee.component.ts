import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-semployee',
  templateUrl: './semployee.component.html',
  styleUrls: ['./semployee.component.css']
})
export class SemployeeComponent implements OnInit {

  employees:any[]=[];

  constructor(private employee:EmployeeService) { }

  ngOnInit(): void {
    this.employees=this.employee.getEmployees();
  }

}
