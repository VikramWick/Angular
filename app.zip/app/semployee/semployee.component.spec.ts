import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SemployeeComponent } from './semployee.component';

describe('SemployeeComponent', () => {
  let component: SemployeeComponent;
  let fixture: ComponentFixture<SemployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SemployeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
