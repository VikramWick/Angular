import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-address-card',
  templateUrl: './address-card.component.html',
  styleUrls: ['./address-card.component.css']
})
export class AddressCardComponent implements OnInit {
 
  user:any;
  currentDate:string=' ';
  constructor() { 
    this.user={
      name:"Reena",
      desig:"mgr",
      salary:5000,
      phone:
      [9874568277,
        2949202456
      ]
    }

  }

  ngOnInit(): void {
    const today = new Date();
    this.currentDate = today.toDateString();
  }

}
