import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeedetail',
  templateUrl: './employeedetail.component.html',
  styleUrls: ['./employeedetail.component.css']
})
export class EmployeedetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
