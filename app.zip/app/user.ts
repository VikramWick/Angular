export class User {
    ename: string = '';
    email: string = '';
    street: string = '';
    city: string = '';
    state: string = '';
    phone: string = '';
    topic: string = '';
    offers: boolean = false;
}
