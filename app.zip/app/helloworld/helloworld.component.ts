import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-helloworld',
  templateUrl: './helloworld.component.html',
  styleUrls: ['./helloworld.component.css']
})
export class HelloworldComponent implements OnInit {

  message:string="";
  constructor() { }

  ngOnInit(): void {
  }
  mess():void{
    this.message="Button was clicked";
  }

}
