import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child2parent',
  templateUrl: './child2parent.component.html',
  styleUrls: ['./child2parent.component.css']
})
export class Child2parentComponent implements OnInit {

  @Output() newItemEvent = new EventEmitter<string>();
  addNewItem(value: string) {
    this.newItemEvent.emit(value);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
